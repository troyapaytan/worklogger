@echo off
"%~dp0node.exe" "%~dp0server.cjs" %*
